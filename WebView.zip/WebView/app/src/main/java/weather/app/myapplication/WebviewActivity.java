package weather.app.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class WebviewActivity extends AppCompatActivity {


    WebView wbview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        wbview = findViewById(R.id.WebView);
        wbview.setWebViewClient(new WebViewClient());
        wbview.loadUrl("https://www.google.ca/");


    }

    @Override
    public void onBackPressed() {

        if (wbview.canGoBack()) {

            wbview.goBack();
            Toast.makeText(this, "Going back inside WebView", Toast.LENGTH_SHORT).show();

        } else {

            Toast.makeText(this, "Exiting WebView", Toast.LENGTH_SHORT).show();
            super.onBackPressed();

        }

    }
}
